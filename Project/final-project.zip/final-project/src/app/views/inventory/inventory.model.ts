export interface Inventory {
    id: string;
    year: number;
    make: string;
    model: string;
    stockNum: string;
  }
